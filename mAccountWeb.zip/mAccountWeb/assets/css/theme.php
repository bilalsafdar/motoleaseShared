<?php

session_start();

header("Content-type: text/css");

$postdata = file_get_contents("php://input");

$themeData = json_decode($postdata, true);

$_SESSION['themeColor'] = $themeData['themeColor'];

print_r($_SESSION['themeColor']);

$themeColor = $_SESSION['themeColor'];

?>
body#maroon #header,body#maroon .mainTitle,body#maroon .FilledBtn,body#maroon md-tabs.md-default-theme md-ink-bar, body#maroon md-tabs md-ink-bar,body#maroon .userBoxHover, body#maroon .md-fab,body#maroon md-switch.md-default-theme.md-checked ._md-thumb,body#maroon md-switch.md-checked ._md-thumb,body#maroon md-checkbox.md-default-theme.md-primary.md-checked:not([disabled]) ._md-icon,body#maroon md-checkbox.md-primary.md-checked:not([disabled]) ._md-icon,body#maroon .md-default-theme .md-calendar-date.md-calendar-selected-date .md-calendar-date-selection-indicator,body#maroon .md-calendar-date.md-calendar-selected-date .md-calendar-date-selection-indicator,body#maroon .md-default-theme .md-calendar-date.md-focus.md-calendar-selected-date .md-calendar-date-selection-indicator,body#maroon .md-calendar-date.md-focus.md-calendar-selected-date .md-calendar-date-selection-indicator,body#maroon md-progress-linear ._md-container:before,body#maroon md-progress-linear ._md-bar,body#maroon md-toolbar.md-default-theme:not(.md-menu-toolbar),body#maroon md-toolbar:not(.md-menu-toolbar),body#maroon .mdp-clock-container .mdp-clock-center,body#maroon .mdp-clock-container .md-button.md-primary,body#maroon .md-button.md-default-theme.md-primary.md-raised,body#maroon .md-button.md-default-theme.md-primary.md-fab,body#maroon .md-button.md-primary.md-fab,body#maroon md-checkbox.md-default-theme.md-checked ._md-icon, md-checkbox.md-checked ._md-icon,body#maroon md-switch.md-default-theme.md-checked ._md-bar,body#maroon md-switch.md-checked ._md-bar,body#maroon .chatPopup .intercom-conversations-header,body#maroon .chatPopup .intercom-comment-container-user .intercom-comment, body#maroon .chatPopup .intercom-conversation-body-profile,body#maroon .applicationInfoSec .uploadDocumentBtn,body#maroon .chatboxCircle,body#maroon .listingHeader, body#maroon .chatPopup h2, body#maroon .mainButton .md-button, body#maroon .mainButton .md-button:hover,body#maroon .pagination > .active > a, body#maroon .pagination > .active > a:focus, body#maroon .pagination > .active > a:hover, body#maroon .pagination > .active > span, body#maroon md-checkbox.md-checked ._md-icon,body#maroon .pagination > .active > span:focus,body#maroon .quotationListingDetail .sellingText,  body#maroon .pagination > .active > span:hover,body#maroon #actionBtn .md-button:hover,body#maroon .time-date > .control > .slider > .date-control > .days .day-cell.selected{ background-color:<?=$themeColor?> !important; }



body#maroon #mainMenu li ul li a:hover,

body#maroon #mainMenu li ul li.active a,

body#maroon #searchContent a,

body#maroon .colorTheme,

body#maroon .md-tab.md-active,

body#maroon .quotationSummaryBox span:first-child,

body#maroon .quotationSummaryFirstBox span,

body#maroon .md-input-focused label,

body#maroon .breadCrumb ul li:last-child a, 

body#maroon .pagination > li > a, .pagination > li > span, 

body#maroon .md-input-has-value label,

body#maroon md-switch.md-default-theme.md-checked .md-ink-ripple,

body#maroon md-switch.md-checked .md-ink-ripple,

body#maroon md-input-container.md-default-theme.md-input-focused:not(.md-input-invalid) label,

body#maroon md-input-container.md-input-focused:not(.md-input-invalid) label,

body#maroon .mdp-timepicker md-dialog-actions .md-button.md-primary, 

body#maroon #fab_ctn .md-button.md-primary:hover:not([disabled]),

body#maroon .accessLink a,

body#maroon md-checkbox.md-default-theme.md-checked .md-ink-ripple,

body#maroon md-checkbox.md-checked .md-ink-ripple,

body#maroon md-select-menu.md-default-theme md-content md-option[selected],

body#maroon md-select-menu md-content md-option[selected],   

body#maroon .menuButton.mainMenuDiv a:hover,

body#maroon .contactUs .material-icons, 

body#maroon #subMenu .md-button.md-primary, 

/*body#maroon .md-dialog-container md-dialog-content ul,*/

body#maroon #fab_ctn.md-default,

body#maroon .md-tab.md-active .cancelButton, 

body#maroon .time-date > .control > .slider > .date-control > .days .day-cell.today


{ color:<?=$themeColor?> !important; }

body#maroon #searchIcon,

body#maroon md-input-container.md-default-theme.md-input-focused:not(.md-input-invalid) .md-input,

body#maroon md-input-container.md-input-focused:not(.md-input-invalid) .md-input,

body#maroon md-select.md-default-theme:focus:not([disabled]) ._md-select-value,

body#maroon md-select:focus:not([disabled]) ._md-select-value,

body#maroon .md-default-theme .md-datepicker-input-container.md-datepicker-focused,

body#maroon .md-datepicker-input-container.md-datepicker-focused,

body#maroon .md-default-theme .md-calendar-date.md-calendar-date-today .md-calendar-date-selection-indicator,

body#maroon .md-calendar-date.md-calendar-date-today .md-calendar-date-selection-indicator, 

body#maroon .pagination > .active > a, 

body#maroon .pagination > .active > a:focus, 

body#maroon .pagination > .active > a:hover, 

body#maroon .pagination > .active > span, 

body#maroon .pagination > .active > span:focus, 

body#maroon .pagination > .active > span:hover

{ border-color:#8f0c2c !important; } 

html.md-default-theme, html, body.md-default-theme, body { background-color: #fff ;}

body#maroon md-input-container.md-input-focused .md-input {
	border-bottom: 2px solid <?=$themeColor?> !important;
} 

body#maroon .pagination > .active > a, 

body#maroon .pagination > .active > a:focus, 

body#maroon .pagination > .active > a:hover, 

body#maroon .pagination > .active > span, 

body#maroon .pagination > .active > span:focus, 

body#maroon .time-date > .control > .slider > .date-control > .days .day-cell.selected,

body#maroon .pagination > .active > span:hover {
	
	color:#FFFFFF !important;
}


body#maroon md-switch.md-default-theme.md-checked ._md-bar,

body#maroon md-switch.md-checked ._md-bar{opacity:.5 !important; }

body#maroon md-checkbox.md-default-theme.md-primary.md-checked.md-focused:not([disabled]) ._md-container::before,

body#maroon md-checkbox.md-primary.md-checked.md-focused:not([disabled]) ._md-container::before{ background-color:transparent !important; opacity:.25 !important; }

body#maroon .md-default-theme .md-datepicker-open .md-datepicker-calendar-icon,

body#maroon .md-datepicker-open .md-datepicker-calendar-icon{ fill:#<?=$themeColor?> !important; }
 
body#maroon md-progress-circular path{ stroke: #<?=$themeColor?> !important; }

body#maroon md-input-container.md-default-theme .md-input, md-input-container .md-input {color: rgba(0,0,0,0.87); border-color: rgba(0,0,0,0.12) !important;}